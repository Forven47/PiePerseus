.class Lcom/android/support/PmsHook$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/android/support/PmsHook;->killPM(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator",
        "<",
        "Landroid/content/pm/PackageInfo;",
        ">;"
    }
.end annotation


# instance fields
.field final val$fakeSignature:Landroid/content/pm/Signature;

.field final val$originalCreator:Landroid/os/Parcelable$Creator;

.field final val$packageName:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/os/Parcelable$Creator;Ljava/lang/String;Landroid/content/pm/Signature;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lcom/android/support/PmsHook$1;->val$originalCreator:Landroid/os/Parcelable$Creator;

    iput-object p2, p0, Lcom/android/support/PmsHook$1;->val$packageName:Ljava/lang/String;

    iput-object p3, p0, Lcom/android/support/PmsHook$1;->val$fakeSignature:Landroid/content/pm/Signature;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createFromParcel(Landroid/os/Parcel;)Landroid/content/pm/PackageInfo;
    .locals 6

    const/4 v2, 0x0

    const-string v0, "\u06e0\u06e2\u06dc\u06d8\u06e8\u06eb\u06d6\u06e5\u06e6\u06df\u06d7\u06d9\u06d9\u06d7\u06e8\u06e8\u06d6\u06e0\u06e6\u06e1\u06ec\u06e8\u06e0\u06da\u06d8\u06e4\u06e5\u06e8\u06d8\u06d7\u06e7\u06da\u06d8\u06e6\u06d7\u06e1\u06db\u06e1\u06d8\u06e7\u06e1\u06eb\u06e0\u06df\u06d8\u06ec\u06e7\u06d8\u06d8\u06ec\u06e0\u06e2\u06eb\u06e4\u06e6\u06d8\u06d8\u06eb\u06df\u06e2\u06e4\u06e8\u06e5\u06e4\u06e4\u06df\u06e4\u06dc\u06d8"

    move-object v1, v0

    :goto_0
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v3, 0x1e6

    xor-int/2addr v0, v3

    xor-int/lit16 v0, v0, 0x1e6

    const/16 v3, 0xc5

    xor-int/2addr v0, v3

    xor-int/lit16 v0, v0, 0x10d

    const/16 v3, 0x229

    xor-int/2addr v0, v3

    xor-int/lit16 v0, v0, 0x325

    const/16 v3, 0x21

    const v4, -0x3b0b1036

    xor-int/2addr v0, v3

    xor-int/2addr v0, v4

    sparse-switch v0, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06eb\u06e6\u06db\u06eb\u06d6\u06e6\u06d8\u06e7\u06e5\u06e1\u06d8\u06e6\u06eb\u06dc\u06d7\u06d6\u06e5\u06e4\u06e6\u06e5\u06d8\u06dc\u06d6\u06e6\u06d8\u06d7\u06d8\u06e8\u06d8\u06eb\u06e0\u06d6\u06df\u06db\u06e2\u06e7\u06da\u06e6\u06e7\u06e1\u06e6\u06e6\u06e6\u06e8\u06e4\u06e0\u06eb\u06e0\u06d8\u06db\u06d8\u06dc\u06d8\u06db\u06e2\u06e4\u06d9\u06e6\u06d9\u06df\u06ec\u06d8\u06e1\u06e1\u06e1\u06d8\u06e4\u06eb\u06da\u06da\u06dc\u06e7\u06e2\u06d9\u06ec\u06e4\u06d7\u06e7"

    move-object v1, v0

    goto :goto_0

    :sswitch_1
    const-string v0, "\u06e2\u06d8\u06e7\u06d8\u06eb\u06e4\u06d9\u06da\u06ec\u06eb\u06e0\u06df\u06ec\u06e5\u06e0\u06d6\u06d8\u06db\u06d9\u06e2\u06da\u06ec\u06e6\u06d8\u06d6\u06da\u06e6\u06dc\u06e6\u06d6\u06d8\u06dc\u06e6\u06df\u06d7\u06d7\u06e1\u06d8\u06eb\u06e6\u06e7\u06df\u06d8\u06e5\u06df\u06e8\u06d8\u06d8\u06e0\u06e0\u06e8\u06d8"

    move-object v1, v0

    goto :goto_0

    :sswitch_2
    iget-object v0, p0, Lcom/android/support/PmsHook$1;->val$originalCreator:Landroid/os/Parcelable$Creator;

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/pm/PackageInfo;

    const-string v1, "\u06d6\u06e7\u06d9\u06e5\u06e7\u06e8\u06d8\u06d8\u06d7\u06d7\u06e7\u06dc\u06e4\u06d9\u06ec\u06eb\u06e0\u06e7\u06db\u06e6\u06da\u06e6\u06e6\u06e1\u06ec\u06d7\u06ec\u06df\u06e6\u06dc\u06d8\u06e8\u06e5\u06eb\u06d9\u06ec\u06eb\u06ec\u06dc\u06db\u06d8\u06e7\u06e8\u06d8\u06df\u06d8\u06e5\u06d6\u06d6\u06e0\u06e7\u06d8\u06e2\u06e4\u06d7\u06d6\u06d8\u06d6\u06db\u06db\u06e6\u06e8\u06d8\u06e6\u06e6\u06dc\u06e4\u06e0\u06e8\u06e7\u06eb\u06e4\u06eb\u06d7\u06e1\u06d8"

    move-object v2, v0

    goto :goto_0

    :sswitch_3
    const v1, -0x4e097ae7

    const-string v0, "\u06e0\u06d9\u06e8\u06d8\u06e1\u06d9\u06dc\u06d8\u06e0\u06e7\u06d8\u06d9\u06e2\u06d8\u06e2\u06dc\u06e1\u06d8\u06e5\u06e5\u06d8\u06e4\u06d9\u06d6\u06db\u06e2\u06e1\u06d8\u06d6\u06d9\u06d6\u06d8\u06e8\u06eb\u06d7\u06da\u06ec\u06d9\u06da\u06dc\u06e7\u06eb\u06e2\u06eb\u06db\u06eb\u06e6\u06d8\u06e5\u06ec\u06e6\u06d8\u06e0\u06d6\u06dc\u06d8\u06d8\u06e6\u06dc\u06d7\u06e6\u06da\u06da\u06e8\u06eb\u06df\u06dc\u06eb\u06d6\u06e2\u06e6\u06eb\u06e1\u06e7\u06d8\u06e7\u06d6\u06d6"

    :goto_1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v1

    sparse-switch v3, :sswitch_data_1

    goto :goto_1

    :sswitch_4
    const v3, -0x15a09a8e

    const-string v0, "\u06eb\u06e2\u06d6\u06d8\u06eb\u06e8\u06e8\u06e8\u06ec\u06e5\u06e4\u06ec\u06eb\u06e4\u06d8\u06eb\u06da\u06da\u06d8\u06e0\u06da\u06d8\u06e5\u06e7\u06d7\u06da\u06d7\u06e4\u06e7\u06db\u06df\u06d7\u06dc\u06e8\u06d8\u06d7\u06ec\u06e8\u06d8\u06e5\u06e5\u06e4\u06e2\u06db\u06d7\u06d7\u06dc\u06e6\u06d8\u06e5\u06e5\u06db\u06e1\u06d7\u06e1\u06d8\u06d9\u06e6\u06d7\u06d7\u06db\u06e7\u06d8\u06db\u06d8\u06d7\u06d8\u06d8\u06da\u06ec\u06d6\u06d8\u06ec\u06d9\u06e0\u06e1\u06e7\u06dc\u06d8\u06dc\u06e7\u06e7\u06df\u06e5\u06e5\u06d7\u06d9\u06d9"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_2

    goto :goto_2

    :sswitch_5
    const v4, -0xf6ca972

    const-string v0, "\u06e0\u06e0\u06e4\u06e4\u06da\u06e5\u06eb\u06ec\u06e0\u06dc\u06e0\u06d6\u06db\u06eb\u06d6\u06d7\u06e1\u06e8\u06e6\u06e1\u06df\u06e8\u06dc\u06ec\u06e2\u06e7\u06e7\u06eb\u06dc\u06e0\u06d9\u06dc\u06e6\u06e4\u06dc\u06d8\u06d6\u06d9\u06e5\u06d8\u06d9\u06df\u06da\u06e2\u06da\u06d6\u06db\u06e6\u06da\u06d9\u06e1\u06e8\u06d8\u06d7\u06da\u06e4"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_3

    goto :goto_3

    :sswitch_6
    const-string v0, "\u06e2\u06eb\u06dc\u06db\u06d8\u06eb\u06e7\u06da\u06e1\u06d8\u06e7\u06d8\u06d6\u06d8\u06e2\u06e4\u06e6\u06eb\u06da\u06ec\u06d6\u06e5\u06e1\u06d8\u06e8\u06e4\u06db\u06e7\u06e1\u06eb\u06d6\u06e1\u06e1\u06d8\u06e5\u06eb\u06e8\u06e4\u06eb\u06e7\u06d8\u06eb\u06e5\u06d7\u06e2\u06eb\u06d7\u06d9\u06e4\u06e5\u06dc\u06e2\u06e6\u06d8\u06d8\u06d6\u06da\u06d9\u06e6\u06e2\u06d8\u06d8\u06dc\u06da\u06e1\u06e0\u06e4\u06e4\u06e8\u06d9\u06e1\u06d8\u06eb\u06d6\u06dc\u06d8\u06d7\u06e1\u06dc\u06e4\u06e2\u06ec\u06da\u06d8\u06dc\u06d8\u06e4\u06e4\u06db"

    goto :goto_2

    :sswitch_7
    const-string v0, "\u06d8\u06d9\u06e2\u06e2\u06e8\u06e4\u06d8\u06dc\u06e2\u06e1\u06e6\u06e4\u06e4\u06df\u06df\u06ec\u06d7\u06e6\u06d8\u06d7\u06ec\u06e5\u06d8\u06d6\u06d9\u06e7\u06d8\u06dc\u06dc\u06e0\u06db\u06dc\u06d8\u06e6\u06e8\u06e5\u06d8\u06d8\u06dc\u06eb\u06dc\u06da\u06dc\u06df\u06eb\u06e0\u06e8\u06d8\u06d8\u06d7\u06e4\u06e1\u06d8\u06e0\u06eb\u06e7\u06e6\u06d7\u06da\u06db\u06ec\u06da\u06ec\u06eb\u06d8\u06d8\u06da\u06d7\u06d8\u06d8"

    goto :goto_1

    :cond_0
    const-string v0, "\u06e4\u06d9\u06e6\u06da\u06df\u06df\u06e0\u06e5\u06da\u06eb\u06d7\u06e4\u06e8\u06ec\u06e1\u06d8\u06e7\u06d8\u06df\u06e1\u06e7\u06dc\u06e7\u06dc\u06d8\u06e6\u06e7\u06e6\u06d8\u06ec\u06e2\u06e8\u06d7\u06d7\u06dc\u06d8\u06d9\u06df\u06e6\u06e5\u06eb\u06d6\u06d8\u06d9\u06e6\u06e7\u06d8\u06ec\u06e7\u06e6\u06d6\u06e2\u06ec\u06e5\u06d6\u06dc\u06e7\u06eb\u06da"

    goto :goto_3

    :sswitch_8
    iget-object v0, v2, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    iget-object v5, p0, Lcom/android/support/PmsHook$1;->val$packageName:Ljava/lang/String;

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "\u06e5\u06e1\u06e1\u06d8\u06e2\u06e2\u06e1\u06eb\u06d6\u06e8\u06e6\u06e4\u06df\u06e1\u06e2\u06d7\u06d6\u06d6\u06d6\u06d8\u06e8\u06d7\u06e4\u06db\u06da\u06e7\u06e8\u06da\u06dc\u06df\u06e8\u06e6\u06ec\u06e8\u06d9\u06df\u06e4\u06d8\u06d8\u06e6\u06d6\u06d8\u06ec\u06e8\u06dc\u06e0\u06e7\u06df\u06eb\u06e4\u06d8\u06e6\u06d8\u06eb\u06dc\u06df\u06ec\u06df\u06d6\u06e2\u06e0\u06eb\u06d8\u06d8\u06da\u06e2\u06d9\u06d6\u06e7\u06e5\u06d8\u06ec\u06d9\u06df\u06db\u06e8\u06e6\u06d8\u06e7\u06e5\u06e1\u06e4\u06ec\u06e0\u06e4"

    goto :goto_3

    :sswitch_9
    const-string v0, "\u06e8\u06db\u06d9\u06dc\u06e2\u06eb\u06d8\u06eb\u06e1\u06da\u06e8\u06e8\u06e2\u06db\u06d8\u06df\u06dc\u06d6\u06d8\u06e4\u06d8\u06d8\u06da\u06e1\u06e6\u06dc\u06e1\u06e7\u06d8\u06dc\u06df\u06df\u06e2\u06eb\u06d8\u06d8\u06e7\u06e7\u06e4\u06eb\u06ec\u06e4\u06e6\u06dc\u06ec\u06da\u06e6\u06e7"

    goto :goto_3

    :sswitch_a
    const-string v0, "\u06e4\u06dc\u06e8\u06d8\u06ec\u06da\u06e8\u06eb\u06e8\u06e8\u06e7\u06e6\u06d8\u06e0\u06e4\u06d6\u06d8\u06e5\u06d7\u06e1\u06d9\u06e2\u06dc\u06e5\u06e7\u06d9\u06d7\u06e4\u06e4\u06db\u06e4\u06e0\u06da\u06d8\u06e0\u06e4\u06d9\u06e7\u06e4\u06d8\u06e1\u06d8\u06e1\u06e6\u06da\u06d8\u06e0\u06d8\u06e4\u06d6\u06e0\u06ec\u06df\u06e4\u06da\u06d8\u06dc\u06d8\u06da\u06df\u06e2\u06da\u06e8\u06e6\u06d8\u06d6\u06e8\u06d6\u06d8\u06e2\u06e1\u06d8\u06da\u06ec\u06d9\u06dc\u06e1\u06df\u06e7\u06d8\u06e0\u06da\u06d8\u06e4\u06e6\u06e0\u06e8"

    goto :goto_2

    :sswitch_b
    const-string v0, "\u06eb\u06dc\u06e2\u06d9\u06e0\u06e8\u06e7\u06d8\u06df\u06d6\u06e7\u06ec\u06da\u06ec\u06e4\u06da\u06e0\u06da\u06e8\u06e1\u06e6\u06d8\u06e0\u06d8\u06ec\u06da\u06dc\u06d6\u06e5\u06e2\u06d6\u06e6\u06e7\u06d9\u06e6\u06d6\u06e1\u06d8\u06e5\u06d9\u06d8\u06d6\u06e7\u06e1\u06e2\u06dc\u06da\u06e8\u06da\u06db\u06eb\u06ec\u06e8\u06d8"

    goto :goto_2

    :sswitch_c
    const-string v0, "\u06eb\u06e0\u06e7\u06e2\u06e7\u06df\u06ec\u06df\u06e6\u06d8\u06df\u06e4\u06e8\u06d8\u06dc\u06eb\u06d8\u06d8\u06d7\u06ec\u06e4\u06e0\u06ec\u06d7\u06d8\u06eb\u06ec\u06d6\u06e7\u06d8\u06eb\u06d8\u06d7\u06e8\u06ec\u06e6\u06d8\u06ec\u06da\u06db\u06da\u06e1\u06ec\u06e6\u06eb\u06e0\u06dc\u06e5\u06e8\u06da\u06e7\u06e6\u06dc\u06eb\u06e5\u06dc\u06e2\u06ec"

    goto :goto_1

    :sswitch_d
    const-string v0, "\u06ec\u06db\u06e7\u06eb\u06d8\u06d8\u06db\u06ec\u06e1\u06e2\u06e0\u06e6\u06e1\u06e2\u06e2\u06d9\u06e5\u06eb\u06ec\u06eb\u06e1\u06df\u06d9\u06e4\u06e7\u06e1\u06d8\u06ec\u06d8\u06d6\u06d8\u06e4\u06e0\u06d8\u06e8\u06e5\u06df\u06ec\u06e0\u06d8\u06da\u06df\u06e4\u06e6\u06e1\u06df\u06e8\u06e2\u06dc\u06d7\u06da\u06e1\u06e1\u06e6\u06dc\u06d8\u06dc\u06e2\u06e6\u06e0\u06e6\u06d7\u06e4\u06ec\u06e1\u06e4\u06d7\u06d8\u06d8\u06d6\u06e2\u06e2\u06e2\u06dc\u06e7\u06d6\u06dc\u06db\u06da\u06dc\u06e1\u06eb\u06db\u06e7"

    goto :goto_1

    :sswitch_e
    const-string v0, "\u06e0\u06df\u06e5\u06db\u06e1\u06e1\u06d8\u06d8\u06db\u06d6\u06d8\u06df\u06e1\u06d8\u06d8\u06da\u06d8\u06dc\u06d8\u06e1\u06e6\u06d8\u06d8\u06df\u06e4\u06d6\u06d8\u06e4\u06e8\u06dc\u06d8\u06e1\u06d7\u06e8\u06d8\u06e6\u06e8\u06d8\u06e6\u06e0\u06e7\u06d7\u06e6\u06e6\u06d8\u06df\u06d9\u06e1\u06ec\u06e8\u06d7\u06e6\u06e5\u06e8\u06da\u06db\u06e8\u06d8\u06e0\u06e0\u06d8\u06e5\u06df\u06e8\u06d7\u06eb\u06e8\u06d8\u06ec\u06e2\u06eb\u06e0\u06df"

    move-object v1, v0

    goto/16 :goto_0

    :sswitch_f
    const v1, -0xb4e5797

    const-string v0, "\u06ec\u06e0\u06e2\u06e0\u06e2\u06d8\u06db\u06da\u06d8\u06d8\u06ec\u06e1\u06da\u06e8\u06e4\u06d7\u06d8\u06df\u06e0\u06d9\u06d9\u06d8\u06d8\u06df\u06e0\u06e1\u06dc\u06df\u06d9\u06db\u06e2\u06d7\u06e7\u06d6\u06e5\u06d8\u06d8\u06dc\u06ec\u06e2\u06e5\u06dc\u06d8\u06e5\u06e5\u06e0\u06e6\u06e5\u06e7\u06d8\u06dc\u06e5\u06e5\u06d8\u06d9\u06da\u06dc\u06e0\u06ec\u06d9\u06e4\u06e8\u06e2\u06d7\u06db\u06dc\u06d8\u06e4\u06e1\u06d8\u06e4\u06e0\u06d7\u06db\u06d7\u06dc\u06d8\u06e5\u06da\u06e4\u06e7\u06e8\u06e2\u06e7\u06e7\u06dc\u06e5\u06eb\u06e2"

    :goto_4
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v1

    sparse-switch v3, :sswitch_data_4

    goto :goto_4

    :sswitch_10
    const-string v0, "\u06e0\u06e6\u06e1\u06d8\u06d9\u06d9\u06d7\u06e8\u06dc\u06d6\u06da\u06df\u06e1\u06d9\u06d7\u06db\u06e4\u06e2\u06d6\u06d8\u06e6\u06e1\u06e1\u06d8\u06e8\u06eb\u06d9\u06e6\u06e0\u06e7\u06e2\u06e6\u06d7\u06d8\u06da\u06db\u06e4\u06e4\u06e1\u06d8\u06e1\u06dc\u06e7\u06d8\u06eb\u06dc\u06e5\u06d8\u06d8\u06e8\u06e0\u06ec\u06ec\u06e8\u06d8\u06d8\u06e6\u06d8\u06d9\u06df\u06e8\u06e1\u06dc\u06e1\u06d8\u06e0\u06dc\u06e4\u06eb\u06db\u06dc"

    move-object v1, v0

    goto/16 :goto_0

    :sswitch_11
    const-string v0, "\u06e1\u06d8\u06e7\u06d8\u06d8\u06eb\u06e6\u06d6\u06da\u06e2\u06d6\u06e4\u06e8\u06df\u06ec\u06d9\u06e7\u06d6\u06e5\u06e4\u06e7\u06da\u06e0\u06df\u06eb\u06e2\u06dc\u06d8\u06e8\u06e8\u06d8\u06d8\u06e4\u06d9\u06e1\u06da\u06d9\u06e1\u06e6\u06e5\u06db\u06d8\u06e7\u06e0\u06da\u06e6\u06d8\u06d8"

    goto :goto_4

    :sswitch_12
    const v3, -0x4fbe1a23

    const-string v0, "\u06da\u06d8\u06e7\u06e4\u06e7\u06ec\u06e1\u06d8\u06e6\u06d8\u06e6\u06e8\u06e5\u06e6\u06e7\u06e2\u06da\u06db\u06da\u06d9\u06dc\u06ec\u06e5\u06d9\u06da\u06d6\u06eb\u06dc\u06eb\u06da\u06e0\u06d9\u06df\u06db\u06e1\u06da\u06dc\u06e1\u06d6\u06d8\u06ec\u06da\u06e0\u06e0\u06e2\u06e4\u06e6\u06d9\u06e6\u06da\u06eb\u06e4\u06ec\u06e6\u06da\u06d7\u06d9\u06d8\u06d7\u06da\u06db\u06d8\u06e0\u06e4\u06e2\u06e8\u06e2\u06e4\u06e5\u06df\u06e7"

    :goto_5
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_5

    goto :goto_5

    :sswitch_13
    const v4, 0x768ab771

    const-string v0, "\u06eb\u06eb\u06e1\u06eb\u06e5\u06e6\u06df\u06df\u06e2\u06db\u06da\u06e6\u06e4\u06e1\u06e6\u06eb\u06e4\u06ec\u06db\u06d7\u06da\u06e8\u06e2\u06dc\u06d8\u06db\u06dc\u06e8\u06d8\u06e7\u06e1\u06d9\u06d6\u06e8\u06e6\u06e5\u06dc\u06e0\u06ec\u06da\u06e6\u06d8\u06e7\u06df\u06d6\u06e6\u06e5\u06ec"

    :goto_6
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_6

    goto :goto_6

    :sswitch_14
    const-string v0, "\u06df\u06d9\u06e1\u06d8\u06e4\u06e5\u06e2\u06db\u06d8\u06e8\u06d8\u06e6\u06df\u06e1\u06d6\u06df\u06db\u06eb\u06e5\u06d8\u06d8\u06e7\u06d8\u06df\u06e7\u06d9\u06e8\u06d8\u06e1\u06eb\u06ec\u06da\u06dc\u06e6\u06d8\u06da\u06e4\u06e5\u06d8\u06eb\u06e7\u06e1\u06df\u06dc\u06df\u06e2\u06e8\u06dc\u06e0\u06e7\u06d9\u06e7\u06e6\u06e0\u06da\u06db\u06e8\u06d7\u06da"

    goto :goto_5

    :cond_1
    const-string v0, "\u06e2\u06d8\u06ec\u06e5\u06e5\u06e0\u06eb\u06e7\u06df\u06e7\u06eb\u06eb\u06e0\u06e7\u06e6\u06d8\u06e1\u06e0\u06db\u06df\u06ec\u06e6\u06e0\u06d6\u06e4\u06e6\u06db\u06db\u06e2\u06da\u06e2\u06e2\u06e1\u06d8\u06d6\u06d8\u06e4\u06e0\u06e6\u06d8\u06da\u06e6\u06e1\u06da\u06e7\u06e1\u06e8\u06e7\u06e4\u06d9\u06e7\u06e8\u06da\u06d6\u06da\u06e5\u06d6\u06e7\u06d8\u06ec\u06d8\u06db\u06e8\u06e5\u06e5\u06d8\u06db\u06d8\u06df\u06d9\u06e0\u06e4\u06eb\u06e2\u06df\u06e0\u06e4\u06e6\u06d8\u06da\u06eb\u06e1\u06d8\u06e6\u06d6\u06df"

    goto :goto_6

    :sswitch_15
    iget-object v0, v2, Landroid/content/pm/PackageInfo;->signingInfo:Landroid/content/pm/SigningInfo;

    if-eqz v0, :cond_1

    const-string v0, "\u06da\u06eb\u06e6\u06d8\u06ec\u06e4\u06e2\u06eb\u06ec\u06d9\u06ec\u06df\u06dc\u06d8\u06df\u06e1\u06d7\u06d9\u06df\u06d9\u06df\u06db\u06e8\u06e4\u06da\u06e7\u06e7\u06d9\u06d9\u06df\u06e8\u06dc\u06d8\u06e0\u06e1\u06e4\u06e6\u06eb\u06dc\u06d7\u06d8\u06e4\u06ec\u06e0\u06eb\u06ec\u06ec\u06e8\u06d8\u06dc\u06df\u06e8\u06d8\u06e8\u06d6\u06da\u06d7\u06e8\u06e1\u06d9\u06db\u06e1\u06e6\u06e1\u06db\u06ec\u06d9\u06e5\u06ec\u06d6\u06db\u06e6\u06d8\u06df\u06d8\u06eb"

    goto :goto_6

    :sswitch_16
    const-string v0, "\u06db\u06d8\u06e0\u06da\u06e6\u06d9\u06da\u06d6\u06dc\u06e5\u06eb\u06eb\u06df\u06df\u06e0\u06db\u06e1\u06d8\u06e8\u06df\u06e1\u06d8\u06d9\u06dc\u06dc\u06e2\u06da\u06e5\u06d6\u06d8\u06d8\u06e5\u06e5\u06d6\u06e6\u06df\u06ec\u06d9\u06d9\u06df\u06df\u06df\u06e8\u06d8\u06e7\u06e6\u06d8\u06db\u06d8\u06eb\u06e2\u06eb\u06e4\u06e1\u06e5\u06d6\u06d9\u06e6\u06e6\u06d8\u06e5\u06e6\u06e8\u06dc\u06e7\u06dc\u06d8"

    goto :goto_6

    :sswitch_17
    const-string v0, "\u06e8\u06e4\u06ec\u06dc\u06e6\u06e5\u06d8\u06df\u06d8\u06e7\u06e4\u06d6\u06e0\u06df\u06d7\u06e1\u06d8\u06e8\u06e0\u06e1\u06d8\u06eb\u06e8\u06ec\u06d8\u06d8\u06df\u06d8\u06db\u06e1\u06e1\u06eb\u06e7\u06d8\u06e7\u06df\u06d9\u06eb\u06e1\u06d9\u06dc\u06db\u06d9\u06d8\u06e4\u06dc\u06dc\u06da\u06e6\u06e4\u06d6\u06d6\u06d9\u06e0\u06da\u06da\u06e8\u06e6\u06d7\u06e6\u06e2\u06e2\u06da\u06e5\u06e1\u06d8"

    goto :goto_5

    :sswitch_18
    const-string v0, "\u06e0\u06d7\u06d8\u06dc\u06ec\u06e6\u06d8\u06e2\u06e2\u06eb\u06e0\u06e7\u06e8\u06d8\u06d6\u06e4\u06e7\u06db\u06d7\u06da\u06e4\u06e2\u06e5\u06d8\u06e2\u06e6\u06d9\u06ec\u06d9\u06eb\u06e0\u06eb\u06da\u06da\u06d6\u06e4\u06e1\u06d6\u06e4\u06e8\u06d7\u06d7\u06d9\u06eb\u06e6\u06d8\u06da\u06e8\u06db\u06d9\u06da\u06e0\u06e4\u06dc\u06ec\u06e1\u06e6\u06e1\u06d8"

    goto :goto_5

    :sswitch_19
    const-string v0, "\u06e5\u06da\u06d8\u06d8\u06d8\u06e2\u06e5\u06e0\u06e6\u06e6\u06e7\u06ec\u06db\u06d7\u06d6\u06d7\u06dc\u06e2\u06e8\u06d8\u06e6\u06d9\u06d7\u06e4\u06d7\u06dc\u06d8\u06eb\u06e5\u06d7\u06db\u06dc\u06e2\u06e0\u06e1\u06e5\u06e5\u06d7\u06d8\u06e5\u06db\u06e1\u06da\u06db\u06eb\u06db\u06eb\u06e1\u06d8\u06e6\u06da\u06dc\u06e7\u06e7\u06dc\u06e7\u06e7\u06e8\u06d8\u06e8\u06d9\u06e5\u06d8\u06df\u06db\u06d9\u06d7\u06e5\u06e5\u06e2\u06e6\u06d8\u06e8\u06d9\u06da\u06e8\u06ec\u06dc\u06d7\u06da\u06db\u06e1\u06e0\u06d9\u06dc\u06e6\u06dc\u06d8"

    goto :goto_4

    :sswitch_1a
    const-string v0, "\u06df\u06d6\u06df\u06d8\u06e5\u06dc\u06d8\u06eb\u06e0\u06e5\u06db\u06eb\u06e1\u06d8\u06e2\u06da\u06e1\u06d8\u06d6\u06e4\u06e8\u06e5\u06d6\u06e5\u06d8\u06e4\u06df\u06e2\u06db\u06ec\u06d6\u06ec\u06e4\u06e5\u06d8\u06e0\u06e0\u06e5\u06d9\u06e1\u06d9\u06dc\u06d7\u06d8\u06d6\u06d9\u06d8\u06d8\u06e7\u06d7\u06e1\u06d8\u06d7\u06e5\u06ec\u06d9\u06d6\u06d6\u06df\u06e1\u06ec\u06d8\u06e5\u06d8\u06d8\u06d7\u06e8\u06d8\u06db\u06dc\u06eb\u06e5\u06eb\u06e1\u06d8\u06d8\u06ec\u06ec\u06d6\u06e7\u06e0\u06dc\u06dc\u06dc\u06d8\u06e6\u06e6\u06e5\u06ec\u06e5\u06ec"

    goto :goto_4

    :sswitch_1b
    const-string v0, "\u06db\u06d8\u06da\u06da\u06da\u06d9\u06d8\u06e1\u06e4\u06e6\u06d8\u06d8\u06e8\u06e0\u06d7\u06e0\u06e6\u06d6\u06d8\u06d6\u06ec\u06e6\u06d8\u06db\u06eb\u06dc\u06d8\u06d7\u06da\u06d7\u06da\u06d8\u06e0\u06d9\u06da\u06eb\u06e5\u06d7\u06eb\u06e2\u06e5\u06e6\u06d8\u06d7\u06e2\u06e2\u06e5\u06e4\u06d8\u06df\u06e2\u06df\u06df\u06d6\u06d8\u06e4\u06eb\u06d8\u06da\u06e8\u06e7\u06e0\u06e2\u06e8\u06d8\u06e4\u06e0\u06e6\u06d8\u06e5\u06db\u06e6\u06e0\u06db\u06d9\u06da\u06e1\u06e5\u06d8"

    move-object v1, v0

    goto/16 :goto_0

    :sswitch_1c
    iget-object v0, v2, Landroid/content/pm/PackageInfo;->signingInfo:Landroid/content/pm/SigningInfo;

    iget-object v1, p0, Lcom/android/support/PmsHook$1;->val$fakeSignature:Landroid/content/pm/Signature;

    invoke-static {v0, v1}, Lcom/android/support/PmsHook;->access$000(Landroid/content/pm/SigningInfo;Landroid/content/pm/Signature;)V

    const-string v0, "\u06e0\u06e6\u06e1\u06d8\u06d9\u06d9\u06d7\u06e8\u06dc\u06d6\u06da\u06df\u06e1\u06d9\u06d7\u06db\u06e4\u06e2\u06d6\u06d8\u06e6\u06e1\u06e1\u06d8\u06e8\u06eb\u06d9\u06e6\u06e0\u06e7\u06e2\u06e6\u06d7\u06d8\u06da\u06db\u06e4\u06e4\u06e1\u06d8\u06e1\u06dc\u06e7\u06d8\u06eb\u06dc\u06e5\u06d8\u06d8\u06e8\u06e0\u06ec\u06ec\u06e8\u06d8\u06d8\u06e6\u06d8\u06d9\u06df\u06e8\u06e1\u06dc\u06e1\u06d8\u06e0\u06dc\u06e4\u06eb\u06db\u06dc"

    move-object v1, v0

    goto/16 :goto_0

    :sswitch_1d
    return-object v2

    :sswitch_data_0
    .sparse-switch
        -0x50d8358e -> :sswitch_3
        -0x508f8553 -> :sswitch_f
        -0x4318560c -> :sswitch_1
        0x180e6be4 -> :sswitch_0
        0x1c5da472 -> :sswitch_1c
        0x27dc307a -> :sswitch_2
        0x67761d00 -> :sswitch_1d
    .end sparse-switch

    :sswitch_data_1
    .sparse-switch
        -0x5414610f -> :sswitch_d
        -0x4777f319 -> :sswitch_10
        0x2d6dfda2 -> :sswitch_4
        0x3f6d64f9 -> :sswitch_e
    .end sparse-switch

    :sswitch_data_2
    .sparse-switch
        -0x5f0e3bb7 -> :sswitch_5
        -0x10dab2c4 -> :sswitch_7
        -0x5a4c4bc -> :sswitch_c
        0x3dadfb0e -> :sswitch_b
    .end sparse-switch

    :sswitch_data_3
    .sparse-switch
        0x21f2d3ac -> :sswitch_9
        0x35c6ea80 -> :sswitch_8
        0x39f4deab -> :sswitch_a
        0x4346c531 -> :sswitch_6
    .end sparse-switch

    :sswitch_data_4
    .sparse-switch
        -0x6c82523a -> :sswitch_10
        0x3454f31d -> :sswitch_1b
        0x49e14a18 -> :sswitch_12
        0x7bc73bd5 -> :sswitch_1a
    .end sparse-switch

    :sswitch_data_5
    .sparse-switch
        -0x40469f05 -> :sswitch_11
        -0x2b25fc9e -> :sswitch_13
        -0x761148b -> :sswitch_18
        0x33100f57 -> :sswitch_19
    .end sparse-switch

    :sswitch_data_6
    .sparse-switch
        -0x21a63eeb -> :sswitch_17
        0x215bb0ff -> :sswitch_16
        0x21ca9449 -> :sswitch_15
        0x79f7f543 -> :sswitch_14
    .end sparse-switch
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 4

    const-string v0, "\u06e6\u06d7\u06e2\u06d7\u06e8\u06e6\u06d8\u06e2\u06ec\u06e6\u06ec\u06e5\u06db\u06e6\u06d6\u06e5\u06da\u06e1\u06d8\u06dc\u06e2\u06d8\u06ec\u06ec\u06e1\u06d9\u06e6\u06d8\u06e2\u06e4\u06e2\u06e1\u06e0\u06e2\u06e8\u06df\u06db\u06e2\u06e2\u06e0\u06e8\u06e5\u06d8\u06d6\u06e0\u06d7"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x313

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x28a

    const/16 v2, 0x1b0

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0xf5

    const/16 v2, 0x376

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x3e4

    const/4 v2, 0x1

    const v3, -0x5e263cf6

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06dc\u06e8\u06e2\u06e1\u06e1\u06e4\u06d6\u06d8\u06d8\u06d8\u06e5\u06e1\u06d8\u06e0\u06e7\u06dc\u06d8\u06dc\u06e4\u06e1\u06d8\u06eb\u06d6\u06d8\u06da\u06eb\u06d8\u06d8\u06d7\u06eb\u06e7\u06e4\u06ec\u06ec\u06e7\u06dc\u06e6\u06e1\u06da\u06d8\u06e4\u06df\u06eb\u06e8\u06e5\u06e8\u06d8\u06db\u06ec\u06e1\u06d9\u06df\u06d6\u06d8\u06dc\u06d8\u06e2\u06df\u06e8\u06e4\u06e6\u06e7\u06e6\u06d8\u06eb\u06eb\u06dc\u06d8\u06e2\u06d6\u06d8\u06d8\u06e2\u06e8\u06e5\u06d8\u06ec\u06db\u06e5\u06e2\u06ec\u06db\u06da\u06db\u06e1\u06ec\u06df\u06d9\u06eb\u06e0\u06e8\u06d8"

    goto :goto_0

    :sswitch_1
    const-string v0, "\u06df\u06e1\u06e8\u06d8\u06e4\u06df\u06eb\u06dc\u06d9\u06e6\u06ec\u06ec\u06db\u06d7\u06da\u06e5\u06d8\u06ec\u06e8\u06d8\u06ec\u06df\u06e6\u06d8\u06d7\u06d6\u06e6\u06d8\u06db\u06e7\u06e2\u06e4\u06df\u06da\u06e0\u06e6\u06ec\u06d7\u06d9\u06ec\u06e8\u06d7\u06d9\u06e0\u06e5\u06d7\u06e4\u06ec\u06dc\u06d6\u06d7\u06e1\u06e4\u06e5\u06d8\u06da\u06df\u06df\u06e0\u06dc\u06e6\u06d8\u06d7\u06e5\u06da\u06e2\u06eb\u06e4\u06e6\u06e4\u06e7\u06db\u06e2\u06e1\u06d8\u06d6\u06d7\u06eb"

    goto :goto_0

    :sswitch_2
    invoke-virtual {p0, p1}, Lcom/android/support/PmsHook$1;->createFromParcel(Landroid/os/Parcel;)Landroid/content/pm/PackageInfo;

    move-result-object v0

    return-object v0

    :sswitch_data_0
    .sparse-switch
        -0x33aaf90e -> :sswitch_0
        0x7fcec55 -> :sswitch_2
        0x4bf7ac64 -> :sswitch_1
    .end sparse-switch
.end method

.method public newArray(I)[Landroid/content/pm/PackageInfo;
    .locals 4

    const-string v0, "\u06d6\u06eb\u06e7\u06df\u06e6\u06e8\u06d6\u06db\u06e4\u06eb\u06db\u06df\u06e6\u06d9\u06e4\u06e7\u06e6\u06e5\u06d8\u06d7\u06db\u06db\u06e1\u06d6\u06e0\u06eb\u06e5\u06d8\u06e2\u06e6\u06eb\u06d9\u06d9\u06e1\u06e6\u06e1\u06e8\u06d8\u06da\u06db\u06e7\u06e8\u06df\u06e8\u06e6\u06e0\u06eb\u06e5\u06e8\u06d8\u06d9\u06df\u06da\u06e2\u06dc\u06e2\u06e2\u06e7\u06e4\u06da\u06d6\u06d8\u06da\u06d9\u06ec\u06eb\u06d6\u06e0\u06db\u06eb\u06e0\u06d9\u06e7\u06dc\u06d8"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xd5

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x2b1

    const/16 v2, 0x1af

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x26e

    const/16 v2, 0x290

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x199

    const/16 v2, 0x258

    const v3, -0x3a8ff8e6

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06e4\u06e1\u06e8\u06d8\u06d7\u06d9\u06dc\u06df\u06df\u06e7\u06d8\u06d7\u06d9\u06eb\u06d6\u06e7\u06d8\u06db\u06ec\u06e0\u06d8\u06e8\u06dc\u06df\u06ec\u06e8\u06d9\u06e5\u06db\u06e2\u06d6\u06e2\u06e0\u06ec\u06e2\u06da\u06e7\u06ec\u06eb\u06e1\u06ec\u06ec\u06eb\u06d7\u06e8\u06e4\u06e2\u06e1\u06d9\u06e2\u06df\u06df\u06db\u06d7\u06da\u06d9\u06e2\u06dc\u06e7\u06e5\u06e8\u06d8\u06e7\u06da\u06d9\u06da\u06e8\u06eb\u06e1\u06d8\u06eb\u06df\u06e2"

    goto :goto_0

    :sswitch_1
    const-string v0, "\u06e7\u06d8\u06dc\u06d8\u06da\u06da\u06dc\u06d9\u06df\u06da\u06d7\u06d9\u06dc\u06df\u06d8\u06db\u06db\u06df\u06e1\u06d8\u06e6\u06d6\u06e6\u06d8\u06e6\u06dc\u06dc\u06d8\u06eb\u06e5\u06dc\u06e4\u06e4\u06eb\u06e2\u06ec\u06d8\u06d8\u06df\u06dc\u06d6\u06e8\u06dc\u06e6\u06d6\u06e6\u06d8\u06d8\u06d6\u06e8\u06d6\u06df\u06db\u06e6\u06d8\u06e5\u06d9\u06d8\u06d8\u06db\u06e2\u06e8\u06d8\u06e1\u06db\u06dc\u06e4\u06ec\u06ec\u06e5\u06db\u06e6\u06d8\u06da\u06d9\u06e8\u06d8\u06db\u06df\u06e6\u06d8\u06d7\u06e7\u06e4"

    goto :goto_0

    :sswitch_2
    iget-object v0, p0, Lcom/android/support/PmsHook$1;->val$originalCreator:Landroid/os/Parcelable$Creator;

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->newArray(I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Landroid/content/pm/PackageInfo;

    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x55c777f2 -> :sswitch_2
        -0x36cf701d -> :sswitch_1
        0xdf09249 -> :sswitch_0
    .end sparse-switch
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 4

    const-string v0, "\u06e0\u06db\u06eb\u06e8\u06e5\u06e8\u06d8\u06e4\u06d7\u06e5\u06d8\u06dc\u06e5\u06eb\u06e6\u06e4\u06ec\u06e8\u06e5\u06e8\u06d8\u06e6\u06da\u06e1\u06d8\u06e2\u06eb\u06e8\u06e5\u06e6\u06e1\u06d9\u06e4\u06e7\u06e6\u06eb\u06dc\u06e1\u06e0\u06db\u06d7\u06ec\u06e5\u06d8\u06e1\u06ec\u06e8\u06df\u06d9\u06d8\u06ec\u06e5\u06d8\u06d8\u06e8\u06e5\u06db\u06da\u06dc\u06eb"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x247

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x233

    const/16 v2, 0x25f

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x58

    const/16 v2, 0x1f4

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0xd8

    const/16 v2, 0x1b5

    const v3, 0xfc40cab

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06e8\u06e2\u06db\u06d7\u06d8\u06e2\u06e6\u06db\u06d8\u06d8\u06d8\u06e5\u06db\u06d8\u06e4\u06d8\u06d8\u06d6\u06da\u06dc\u06ec\u06d8\u06d6\u06db\u06d8\u06db\u06e1\u06e2\u06dc\u06db\u06da\u06dc\u06d8\u06d8\u06e1\u06d7\u06e2\u06ec\u06d9\u06ec\u06dc\u06d8\u06db\u06e1\u06e2\u06e8\u06da\u06e5\u06d8\u06e1\u06e6\u06d6\u06e4\u06e4\u06eb\u06e6\u06e6\u06d8\u06e6\u06d9\u06d6\u06e1\u06d9\u06ec\u06e2\u06eb\u06e6\u06d8"

    goto :goto_0

    :sswitch_1
    const-string v0, "\u06dc\u06d7\u06e6\u06e7\u06e7\u06d7\u06e4\u06eb\u06d8\u06d9\u06ec\u06d6\u06e0\u06d7\u06dc\u06e5\u06da\u06e0\u06d7\u06d8\u06df\u06e6\u06e0\u06dc\u06d8\u06e2\u06df\u06d6\u06d8\u06d8\u06e6\u06e2\u06e4\u06df\u06eb\u06ec\u06e4\u06e5\u06d8\u06dc\u06da\u06e4\u06eb\u06eb\u06e6\u06d8\u06e2\u06d7\u06d9\u06e8\u06d8\u06e6\u06d8\u06dc\u06d8\u06e1\u06d8\u06e0\u06ec\u06ec\u06e5\u06da\u06d7\u06e6\u06d7\u06e7\u06d7\u06db\u06e8\u06d8\u06e1\u06d7\u06df\u06df\u06df\u06eb\u06e7\u06e5\u06eb\u06d6\u06db\u06e5\u06ec\u06ec\u06eb\u06d6\u06da"

    goto :goto_0

    :sswitch_2
    invoke-virtual {p0, p1}, Lcom/android/support/PmsHook$1;->newArray(I)[Landroid/content/pm/PackageInfo;

    move-result-object v0

    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x69bbb638 -> :sswitch_2
        -0x57167019 -> :sswitch_0
        0x526a4480 -> :sswitch_1
    .end sparse-switch
.end method
