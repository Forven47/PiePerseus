.class public Lcom/android/support/Launcher;
.super Landroid/app/Service;


# instance fields
.field menu:Lcom/android/support/Menu;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/android/support/Launcher;)V
    .locals 4

    const-string v0, "\u06df\u06e2\u06d9\u06dc\u06e2\u06d9\u06e5\u06e8\u06e7\u06d8\u06e8\u06d6\u06e7\u06d8\u06e8\u06dc\u06e8\u06d8\u06db\u06e2\u06e1\u06d7\u06e8\u06e1\u06d8\u06ec\u06e2\u06d6\u06e7\u06db\u06d8\u06d8\u06d8\u06e1\u06d8\u06d8\u06e1\u06db\u06df\u06da\u06ec\u06e7\u06e8\u06d6\u06e2\u06db\u06df\u06e4\u06e8\u06e2"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x2a3

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x326

    const/16 v2, 0x281

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x49

    const/16 v2, 0x54

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0xf2

    const/16 v2, 0x28a

    const v3, 0x742fb6a0

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06db\u06eb\u06e1\u06d8\u06e5\u06db\u06dc\u06e6\u06e1\u06e8\u06d8\u06dc\u06d8\u06d8\u06e1\u06d8\u06da\u06e8\u06e8\u06d8\u06d7\u06d9\u06dc\u06d8\u06e2\u06db\u06e4\u06e1\u06d9\u06df\u06d9\u06df\u06db\u06ec\u06e1\u06e8\u06e2\u06d6\u06d6\u06e0\u06eb\u06e2\u06d8\u06d9\u06e5\u06e6\u06e1\u06dc\u06d8\u06e6\u06df\u06d9\u06e0\u06ec\u06e8\u06e2\u06df\u06e2"

    goto :goto_0

    :sswitch_1
    invoke-direct {p0}, Lcom/android/support/Launcher;->checkGameState()V

    const-string v0, "\u06da\u06e4\u06dc\u06e8\u06e8\u06dc\u06e5\u06e6\u06d8\u06db\u06ec\u06dc\u06d8\u06d6\u06dc\u06da\u06dc\u06e8\u06df\u06e6\u06d8\u06d8\u06d8\u06db\u06e1\u06e1\u06d7\u06d6\u06e2\u06dc\u06e6\u06e2\u06e8\u06e4\u06df\u06e0\u06e6\u06e8\u06e5\u06e0\u06e1\u06e4\u06df\u06df\u06e6\u06e5\u06d6\u06d8\u06d6\u06d6\u06d6\u06d8\u06df\u06ec\u06e6\u06eb\u06d8\u06df\u06d7\u06e1\u06d6\u06d8\u06dc\u06eb\u06d6\u06d6\u06da\u06e7"

    goto :goto_0

    :sswitch_2
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x711675f9 -> :sswitch_2
        -0x56bbdb5c -> :sswitch_0
        0x6e2ab643 -> :sswitch_1
    .end sparse-switch
.end method

.method private checkGameState()V
    .locals 5

    const-string v0, "\u06d6\u06e2\u06e6\u06d8\u06e2\u06e8\u06dc\u06d8\u06db\u06eb\u06e8\u06d6\u06e6\u06d7\u06df\u06d6\u06e4\u06e0\u06d9\u06e1\u06d8\u06e2\u06e5\u06e4\u06e1\u06df\u06d8\u06d8\u06e0\u06e5\u06d6\u06e8\u06e6\u06dc\u06da\u06da\u06dc\u06e2\u06d6\u06e7\u06d8\u06e2\u06d7\u06d6\u06d8\u06d9\u06df\u06df\u06d6\u06e1\u06da"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0xf8

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x156

    const/16 v2, 0x2a6

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x329

    const/16 v2, 0xa3

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x166

    const/16 v2, 0x22c

    const v3, -0x4b2b979d

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06e4\u06e2\u06e0\u06da\u06e2\u06e7\u06d6\u06dc\u06e6\u06d6\u06d6\u06d9\u06e8\u06e4\u06d6\u06d8\u06ec\u06eb\u06e1\u06d8\u06eb\u06d8\u06d8\u06d6\u06d8\u06d7\u06e7\u06d7\u06d8\u06d8\u06df\u06e8\u06e8\u06d8\u06e6\u06ec\u06e8\u06e0\u06d8\u06db\u06e0\u06e2\u06e8\u06d8\u06d8\u06d9\u06e1\u06d8\u06d7\u06e0\u06e1\u06d8\u06d6\u06df\u06d8\u06e1\u06eb\u06e8\u06d8\u06d7\u06e2\u06ec\u06dc\u06d6\u06d9\u06da\u06e4\u06da\u06e6\u06e6\u06d7"

    goto :goto_0

    :sswitch_1
    const v1, 0x6fd5cdc8

    const-string v0, "\u06e1\u06e1\u06e7\u06e8\u06eb\u06e1\u06e8\u06d8\u06d8\u06d8\u06e2\u06db\u06d9\u06d9\u06d9\u06e4\u06e6\u06e0\u06e0\u06da\u06d9\u06dc\u06e8\u06df\u06e4\u06e6\u06ec\u06e1\u06e6\u06e8\u06e6\u06d8\u06ec\u06db\u06e1\u06e8\u06e2\u06e8\u06e4\u06d7\u06e8\u06d8\u06e4\u06ec\u06d9\u06e5\u06e5\u06d9"

    :goto_1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    xor-int/2addr v2, v1

    sparse-switch v2, :sswitch_data_1

    goto :goto_1

    :sswitch_2
    const v2, 0x6389f563

    const-string v0, "\u06d9\u06da\u06ec\u06d7\u06e0\u06e5\u06d8\u06d8\u06d9\u06dc\u06d8\u06e5\u06e2\u06e6\u06d8\u06e4\u06e4\u06e1\u06d8\u06e4\u06e2\u06dc\u06d8\u06e6\u06db\u06e4\u06d9\u06e0\u06da\u06e4\u06e7\u06ec\u06d9\u06ec\u06e1\u06d8\u06e7\u06e8\u06d7\u06d7\u06ec\u06e7\u06d6\u06dc\u06e4\u06e8\u06d7\u06d6\u06d8\u06df\u06da\u06e7"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_2

    goto :goto_2

    :sswitch_3
    const-string v0, "\u06e7\u06d6\u06d6\u06d8\u06d6\u06ec\u06e7\u06e0\u06e5\u06ec\u06ec\u06d8\u06ec\u06e7\u06df\u06d8\u06d9\u06ec\u06d8\u06d8\u06e6\u06e8\u06e6\u06d8\u06e4\u06e1\u06e5\u06d8\u06e1\u06d7\u06e1\u06d8\u06e4\u06d7\u06dc\u06d8\u06e8\u06e4\u06d6\u06d8\u06d8\u06e8\u06d9\u06e0\u06d8\u06da\u06e8\u06d6\u06d9\u06e8\u06e0\u06d7\u06da\u06dc\u06d7\u06db\u06d6\u06d8\u06e1\u06d6\u06d8"

    goto :goto_2

    :sswitch_4
    const-string v0, "\u06e2\u06e6\u06e8\u06d8\u06db\u06d6\u06e7\u06e2\u06da\u06e5\u06d8\u06e7\u06e1\u06e6\u06da\u06df\u06e8\u06e0\u06e8\u06e2\u06ec\u06df\u06e4\u06ec\u06e0\u06db\u06ec\u06da\u06d7\u06e2\u06e5\u06d8\u06ec\u06d8\u06e1\u06d8\u06eb\u06e0\u06da\u06e0\u06d8\u06e8\u06e0\u06e0\u06e5\u06d8\u06e7\u06ec\u06e5"

    goto :goto_1

    :sswitch_5
    const-string v0, "\u06da\u06d9\u06ec\u06da\u06df\u06e8\u06e5\u06ec\u06db\u06df\u06e5\u06e0\u06d6\u06d8\u06e5\u06d8\u06eb\u06dc\u06d6\u06db\u06d9\u06d6\u06d8\u06d8\u06e7\u06e1\u06d8\u06ec\u06db\u06eb\u06da\u06e0\u06e7\u06dc\u06d8\u06d9\u06e7\u06e6\u06d8\u06df\u06e0\u06ec\u06e8\u06e6\u06e2\u06eb\u06d9\u06dc\u06d8\u06e7\u06ec\u06e0\u06d6\u06e7\u06d8\u06e4\u06d9\u06ec"

    goto :goto_2

    :sswitch_6
    const v3, 0xb46b1ef

    const-string v0, "\u06e0\u06d8\u06e2\u06d9\u06ec\u06dc\u06db\u06da\u06d7\u06e8\u06e6\u06ec\u06d9\u06eb\u06e5\u06d6\u06e1\u06da\u06ec\u06da\u06d7\u06dc\u06e6\u06e4\u06e6\u06e5\u06d8\u06db\u06d9\u06d8\u06d9\u06db\u06df\u06e2\u06e0\u06e1\u06d8\u06e0\u06e6\u06d7\u06db\u06e6\u06d6\u06d8\u06d6\u06d6\u06e6\u06da\u06da\u06dc\u06d7\u06db\u06e2\u06dc\u06db\u06e5\u06e7\u06e2\u06eb\u06d8\u06ec\u06d6\u06e4\u06da\u06d7\u06e1\u06d7\u06df\u06e6\u06d9\u06e0\u06dc\u06e7\u06ec"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_3

    goto :goto_3

    :sswitch_7
    const-string v0, "\u06d9\u06e7\u06d7\u06db\u06e7\u06e8\u06d8\u06d8\u06d8\u06e5\u06e4\u06e5\u06e8\u06d8\u06e2\u06e1\u06ec\u06df\u06e5\u06d9\u06d7\u06e4\u06d6\u06d8\u06e0\u06d9\u06d9\u06d6\u06da\u06d6\u06df\u06e0\u06e5\u06d6\u06d7\u06e7\u06db\u06d6\u06d9\u06e7\u06e7\u06d6\u06d8\u06e4\u06dc\u06e2\u06d6\u06e5\u06dc\u06d8\u06e7\u06e4\u06e4\u06da\u06da\u06e4\u06df\u06e4\u06dc\u06df\u06da\u06db\u06eb\u06eb\u06e8\u06d8\u06e4"

    goto :goto_3

    :cond_0
    const-string v0, "\u06df\u06db\u06d6\u06e7\u06e7\u06e8\u06d8\u06eb\u06e2\u06e6\u06d8\u06e0\u06e8\u06e1\u06d8\u06e1\u06e0\u06e5\u06e8\u06d9\u06e0\u06e4\u06da\u06e4\u06e8\u06d6\u06dc\u06d8\u06ec\u06e0\u06e1\u06e1\u06e7\u06e0\u06e6\u06d8\u06d9\u06d8\u06e7\u06e0\u06df\u06e6\u06d8\u06d8\u06ec\u06ec\u06e7\u06e0\u06d8\u06e5\u06d7\u06e8\u06e6\u06d8\u06d7\u06eb\u06d8\u06e8\u06dc\u06e6\u06ec\u06d8\u06d8\u06d8\u06db\u06e2\u06e6\u06ec\u06e8"

    goto :goto_3

    :sswitch_8
    invoke-direct {p0}, Lcom/android/support/Launcher;->isNotInGame()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "\u06dc\u06d9\u06d8\u06e1\u06e4\u06d8\u06d8\u06e6\u06e8\u06e0\u06db\u06e1\u06d8\u06d7\u06e2\u06e5\u06d8\u06e0\u06d6\u06db\u06e6\u06ec\u06e0\u06e1\u06df\u06e6\u06dc\u06e7\u06d8\u06e2\u06e1\u06e8\u06d8\u06dc\u06e7\u06e6\u06e8\u06e4\u06e7\u06e2\u06eb\u06e5\u06db\u06db\u06e7\u06e8\u06d7\u06db"

    goto :goto_3

    :sswitch_9
    const-string v0, "\u06e4\u06ec\u06e6\u06d8\u06d7\u06d7\u06d6\u06d8\u06d6\u06e5\u06df\u06dc\u06d7\u06eb\u06ec\u06df\u06e8\u06d9\u06d6\u06e4\u06e1\u06eb\u06da\u06da\u06db\u06ec\u06d9\u06e5\u06d6\u06d8\u06e2\u06e4\u06e0\u06d8\u06db\u06db\u06e6\u06e6\u06da\u06d6\u06e0\u06e6\u06d8\u06ec\u06e5\u06db\u06df\u06eb\u06d8\u06d8\u06d9\u06d9\u06dc\u06d8\u06d6\u06e6\u06e7\u06da\u06e1\u06d7\u06e1\u06e2\u06e8\u06db\u06d6\u06e7\u06e8\u06e8\u06e0\u06e0\u06e1\u06df\u06e6\u06d6\u06dc\u06d8\u06e6\u06e5\u06d6\u06d8"

    goto :goto_2

    :sswitch_a
    const-string v0, "\u06e6\u06d8\u06e2\u06e4\u06db\u06dc\u06d8\u06ec\u06d9\u06e5\u06d8\u06e8\u06da\u06e1\u06df\u06e5\u06e7\u06e0\u06df\u06e6\u06e1\u06da\u06e0\u06e4\u06e1\u06e0\u06e8\u06e6\u06da\u06d9\u06e0\u06e5\u06d8\u06db\u06d6\u06e6\u06d8\u06e4\u06e5\u06e5\u06d8\u06eb\u06e1\u06d9\u06e1\u06d9\u06e2\u06e2\u06e5\u06e7\u06df\u06e6\u06da\u06eb\u06d9\u06e8\u06d8\u06dc\u06e0\u06d7\u06d9\u06d7\u06eb\u06e6\u06e5\u06eb\u06e8\u06da\u06e5\u06e4\u06ec\u06ec\u06e8\u06e0\u06d8\u06d8\u06ec\u06ec\u06e8\u06d8\u06d6\u06e1\u06e1\u06d6\u06e6\u06db\u06e1\u06e8"

    goto :goto_1

    :sswitch_b
    const-string v0, "\u06eb\u06eb\u06d8\u06d8\u06d6\u06e4\u06e5\u06d8\u06e8\u06d9\u06d8\u06e0\u06e2\u06e1\u06e8\u06e0\u06e5\u06d8\u06e5\u06e2\u06dc\u06d8\u06e8\u06e2\u06da\u06eb\u06e1\u06d8\u06e0\u06eb\u06d9\u06d6\u06dc\u06e8\u06e5\u06e8\u06d8\u06df\u06e7\u06d8\u06d8\u06e1\u06e1\u06d7\u06df\u06da\u06e6\u06d8\u06e4\u06e5\u06d8\u06e1\u06df\u06e8\u06df\u06d7\u06e5\u06d8\u06d9\u06e2\u06df\u06da\u06e5\u06e8\u06e1\u06da\u06dc\u06df\u06eb\u06dc\u06d8"

    goto :goto_1

    :sswitch_c
    const-string v0, "\u06db\u06e2\u06e8\u06eb\u06e2\u06e5\u06d7\u06db\u06d6\u06d8\u06ec\u06eb\u06ec\u06e1\u06e1\u06d6\u06d8\u06db\u06e7\u06da\u06e1\u06e4\u06e4\u06e8\u06e4\u06d8\u06e6\u06db\u06e4\u06e6\u06e0\u06d8\u06e2\u06d9\u06e8\u06d6\u06d6\u06d9\u06db\u06eb\u06d9\u06dc\u06da\u06da\u06e1\u06db\u06e5\u06d8\u06e8\u06eb\u06d9\u06db\u06d9\u06e4\u06e8\u06d9\u06e1\u06e7\u06df\u06e5\u06d6\u06e1\u06e7\u06dc\u06e2\u06d6\u06e4\u06d6\u06da\u06da\u06ec\u06e1\u06da\u06df\u06d9"

    goto :goto_0

    :sswitch_d
    iget-object v0, p0, Lcom/android/support/Launcher;->menu:Lcom/android/support/Menu;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lcom/android/support/Menu;->setVisibility(I)V

    const-string v0, "\u06e7\u06e7\u06df\u06e4\u06e7\u06d7\u06e6\u06e2\u06e4\u06e6\u06d6\u06d6\u06eb\u06e7\u06e1\u06e0\u06db\u06e2\u06d9\u06e1\u06d6\u06e8\u06e5\u06d8\u06e0\u06d9\u06e2\u06e6\u06db\u06e8\u06d8\u06e5\u06e6\u06d9\u06df\u06d8\u06e1\u06d8\u06e4\u06d7\u06db\u06d9\u06e5\u06e5\u06ec\u06d9\u06d6\u06d8"

    goto :goto_0

    :sswitch_e
    iget-object v0, p0, Lcom/android/support/Launcher;->menu:Lcom/android/support/Menu;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/android/support/Menu;->setVisibility(I)V

    const-string v0, "\u06da\u06e1\u06e7\u06d8\u06e1\u06d9\u06db\u06e4\u06e5\u06e0\u06e1\u06eb\u06da\u06db\u06e0\u06e7\u06d7\u06e7\u06eb\u06d7\u06dc\u06e2\u06e1\u06e5\u06e7\u06d8\u06d8\u06eb\u06e6\u06e7\u06e0\u06e5\u06d9\u06e7\u06e1\u06d7\u06ec\u06e5\u06ec\u06e7\u06d7\u06e2\u06e6\u06eb\u06e6\u06d9\u06da\u06e0\u06e4\u06d7\u06d6\u06e6\u06e6"

    goto :goto_0

    :sswitch_f
    const-string v0, "\u06ec\u06eb\u06d8\u06d8\u06e5\u06e2\u06ec\u06dc\u06db\u06df\u06df\u06e2\u06e8\u06e4\u06e5\u06da\u06e1\u06ec\u06dc\u06d8\u06dc\u06d9\u06eb\u06df\u06db\u06d6\u06d8\u06d6\u06d8\u06db\u06d8\u06e2\u06e8\u06d8\u06e5\u06d8\u06e7\u06e5\u06e7\u06d8\u06ec\u06e5\u06d9\u06e7\u06df\u06e5\u06d8\u06e8\u06e6\u06e8"

    goto/16 :goto_0

    :sswitch_10
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x140982d9 -> :sswitch_10
        0x158ce27b -> :sswitch_0
        0x29380e78 -> :sswitch_e
        0x768ac357 -> :sswitch_10
        0x7cca110d -> :sswitch_1
        0x7e939063 -> :sswitch_d
    .end sparse-switch

    :sswitch_data_1
    .sparse-switch
        -0x7085173c -> :sswitch_c
        -0x48d2ab0b -> :sswitch_f
        0x26fbfec3 -> :sswitch_2
        0x46d3b3a2 -> :sswitch_b
    .end sparse-switch

    :sswitch_data_2
    .sparse-switch
        -0x5a576df2 -> :sswitch_4
        -0x172a9ecb -> :sswitch_a
        -0x16cecff3 -> :sswitch_3
        0xa3e6307 -> :sswitch_6
    .end sparse-switch

    :sswitch_data_3
    .sparse-switch
        -0x48057850 -> :sswitch_9
        0x45b7792 -> :sswitch_5
        0x6bead977 -> :sswitch_7
        0x7054b434 -> :sswitch_8
    .end sparse-switch
.end method

.method private isNotInGame()Z
    .locals 6

    const/4 v1, 0x0

    const-string v0, "\u06e1\u06e7\u06e2\u06e4\u06d8\u06e1\u06e8\u06eb\u06dc\u06d8\u06e1\u06e4\u06d7\u06dc\u06d8\u06dc\u06d7\u06d6\u06d8\u06df\u06db\u06e1\u06db\u06dc\u06d8\u06e0\u06e6\u06d7\u06eb\u06e1\u06d6\u06d8\u06e4\u06e5\u06d9\u06e5\u06dc\u06dc\u06d8\u06e8\u06df\u06e1\u06e6\u06e1\u06e5\u06d8\u06e2\u06e0\u06d8\u06d8\u06dc\u06d9\u06e1\u06db\u06e8\u06d8\u06db\u06db\u06d7"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x252

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x331

    const/16 v3, 0xb4

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x367

    const/16 v3, 0x1f0

    xor-int/2addr v2, v3

    xor-int/lit16 v2, v2, 0x389

    const/16 v3, 0x3ca

    const v4, 0x2d6d58e0

    xor-int/2addr v2, v3

    xor-int/2addr v2, v4

    sparse-switch v2, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06dc\u06ec\u06db\u06dc\u06e0\u06da\u06e6\u06d7\u06df\u06e4\u06e4\u06e1\u06df\u06db\u06e7\u06e4\u06d7\u06e2\u06da\u06eb\u06dc\u06dc\u06df\u06d7\u06ec\u06e0\u06e7\u06d6\u06e6\u06df\u06da\u06d6\u06e8\u06e5\u06e4\u06d8\u06e1\u06d9\u06e7\u06d8\u06d6\u06e1\u06d6\u06e1\u06e7\u06d8"

    goto :goto_0

    :sswitch_1
    new-instance v1, Landroid/app/ActivityManager$RunningAppProcessInfo;

    invoke-direct {v1}, Landroid/app/ActivityManager$RunningAppProcessInfo;-><init>()V

    const-string v0, "\u06e5\u06e2\u06d8\u06d8\u06e0\u06ec\u06d8\u06d8\u06e7\u06eb\u06e8\u06d6\u06e4\u06e8\u06d6\u06d8\u06df\u06d8\u06e2\u06e1\u06da\u06dc\u06df\u06df\u06d8\u06e8\u06d8\u06df\u06dc\u06e8\u06e8\u06db\u06e4\u06d9\u06e8\u06e5\u06eb\u06dc\u06ec\u06e2\u06e7\u06e6\u06d8\u06eb\u06eb\u06e0\u06e1\u06d8\u06d9\u06e8\u06e4\u06e6\u06d8\u06db\u06da\u06d6\u06e2\u06eb\u06e6\u06d6\u06e7\u06e5\u06d6\u06df\u06e1\u06d8\u06d7\u06e0\u06da\u06d7\u06da\u06e5\u06d8\u06e2\u06e8\u06e1\u06ec\u06d9\u06e4\u06d6\u06e4\u06e5\u06df\u06df\u06e7\u06ec\u06e5\u06d6"

    goto :goto_0

    :sswitch_2
    invoke-static {v1}, Landroid/app/ActivityManager;->getMyMemoryState(Landroid/app/ActivityManager$RunningAppProcessInfo;)V

    const-string v0, "\u06da\u06eb\u06da\u06d7\u06eb\u06d9\u06e0\u06db\u06db\u06ec\u06e7\u06d6\u06e4\u06d6\u06e4\u06d9\u06e5\u06d8\u06e5\u06df\u06d6\u06dc\u06dc\u06dc\u06d8\u06d8\u06d7\u06e8\u06d8\u06e8\u06ec\u06e8\u06d8\u06e0\u06e5\u06ec\u06e6\u06d8\u06e5\u06d6\u06dc\u06d8\u06da\u06d7\u06e7\u06eb\u06e8"

    goto :goto_0

    :sswitch_3
    const v2, -0x2b2f7427

    const-string v0, "\u06e1\u06e8\u06dc\u06d8\u06e7\u06e5\u06e1\u06d8\u06eb\u06dc\u06d6\u06d8\u06d7\u06e1\u06e6\u06d6\u06da\u06e7\u06e6\u06db\u06db\u06e6\u06e4\u06ec\u06db\u06dc\u06e8\u06e0\u06df\u06e4\u06e8\u06e5\u06d9\u06e7\u06d6\u06df\u06d7\u06ec\u06d9\u06e1\u06dc\u06eb\u06ec\u06e6\u06e8\u06d8\u06e4\u06e7\u06e5"

    :goto_1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v3

    xor-int/2addr v3, v2

    sparse-switch v3, :sswitch_data_1

    goto :goto_1

    :sswitch_4
    const-string v0, "\u06d9\u06ec\u06db\u06dc\u06ec\u06d6\u06d8\u06d7\u06e4\u06e8\u06d8\u06e4\u06ec\u06da\u06e6\u06e1\u06df\u06e8\u06ec\u06d6\u06d8\u06df\u06df\u06e6\u06d8\u06e4\u06df\u06e6\u06d8\u06e2\u06e1\u06d7\u06dc\u06df\u06e5\u06d6\u06da\u06d6\u06e4\u06d6\u06e1\u06e0\u06e8\u06d8\u06e8\u06e8\u06e4\u06db\u06db\u06e5\u06e1\u06e2\u06eb\u06e7\u06dc\u06d8\u06e0\u06dc\u06db"

    goto :goto_0

    :sswitch_5
    const-string v0, "\u06dc\u06d7\u06d7\u06e2\u06e1\u06dc\u06e1\u06eb\u06ec\u06e0\u06e6\u06db\u06e2\u06d8\u06e4\u06e4\u06e1\u06d6\u06d8\u06e4\u06ec\u06e0\u06db\u06e8\u06da\u06da\u06e7\u06dc\u06da\u06da\u06d8\u06d8\u06eb\u06e0\u06e2\u06df\u06d7\u06e6\u06d8\u06e1\u06da\u06e1\u06d8\u06dc\u06e7\u06dc\u06d8\u06e6\u06d7\u06e5\u06d8\u06e7\u06e7\u06eb\u06da\u06df\u06ec\u06eb\u06db\u06d8\u06eb\u06e1\u06eb\u06d7\u06e8\u06e0\u06df\u06d6\u06d6\u06d8\u06e4\u06e2\u06d8\u06d8\u06d7\u06eb\u06e4\u06d7\u06e7\u06e2\u06d6\u06e0\u06df\u06d9\u06d6\u06df\u06dc\u06d7\u06df"

    goto :goto_1

    :sswitch_6
    const v3, -0x74db9652

    const-string v0, "\u06d6\u06e4\u06e1\u06d8\u06ec\u06db\u06e7\u06e4\u06df\u06e5\u06e4\u06da\u06e8\u06d8\u06d9\u06e5\u06da\u06dc\u06e8\u06d9\u06e6\u06ec\u06d6\u06d8\u06eb\u06e4\u06e1\u06d8\u06d7\u06dc\u06e2\u06df\u06d6\u06d8\u06d8\u06e0\u06e4\u06e8\u06d8\u06eb\u06e7\u06dc\u06df\u06d7\u06dc\u06ec\u06da\u06dc"

    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    xor-int/2addr v4, v3

    sparse-switch v4, :sswitch_data_2

    goto :goto_2

    :sswitch_7
    const-string v0, "\u06eb\u06df\u06e8\u06d8\u06d6\u06e0\u06e6\u06e1\u06d6\u06e8\u06e0\u06e1\u06d8\u06d9\u06dc\u06e1\u06da\u06ec\u06e0\u06ec\u06db\u06e7\u06e1\u06d8\u06e5\u06d8\u06ec\u06e5\u06e8\u06e6\u06eb\u06e8\u06d8\u06e0\u06d7\u06dc\u06d8\u06d6\u06e1\u06d8\u06eb\u06da\u06d6\u06e4\u06d6\u06e6\u06e7\u06e6\u06e8\u06d8\u06e5\u06e6\u06eb\u06dc\u06e2\u06e4\u06e1\u06e2\u06d9\u06eb\u06d9\u06e2\u06d7\u06dc\u06e5\u06d9\u06e1\u06e5\u06d8\u06d8\u06dc\u06dc\u06d8\u06e6\u06dc\u06db\u06ec\u06e0\u06eb\u06e1\u06e5\u06dc\u06d8\u06e8\u06e8\u06dc\u06e2\u06e4\u06d6\u06d8"

    goto :goto_1

    :sswitch_8
    const-string v0, "\u06e7\u06d9\u06df\u06e4\u06d8\u06e6\u06da\u06e6\u06e5\u06d8\u06d7\u06da\u06da\u06ec\u06eb\u06db\u06ec\u06dc\u06e2\u06dc\u06d9\u06e8\u06df\u06d7\u06e1\u06d8\u06e6\u06e7\u06d9\u06e7\u06e7\u06d9\u06d8\u06d9\u06e6\u06d8\u06d7\u06e1\u06d6\u06d8\u06e7\u06e2\u06d6\u06d8\u06e4\u06db\u06ec\u06e2\u06dc\u06df\u06d9\u06d6\u06dc\u06eb\u06e8\u06d8\u06d8\u06da\u06e1\u06e6\u06d8"

    goto :goto_2

    :sswitch_9
    const v4, 0x130857e0

    const-string v0, "\u06ec\u06df\u06e1\u06e7\u06df\u06e8\u06eb\u06eb\u06ec\u06d9\u06d7\u06e1\u06da\u06e2\u06e8\u06d8\u06e5\u06df\u06e6\u06d8\u06d9\u06e8\u06d8\u06e2\u06da\u06e6\u06e8\u06df\u06dc\u06d8\u06d7\u06d7\u06e0\u06d9\u06e8\u06d8\u06e7\u06d9\u06e7\u06eb\u06e2\u06ec\u06e1\u06df\u06e1\u06e4\u06d6\u06e8\u06e4\u06d8\u06e6\u06da\u06e8\u06ec\u06e6\u06e6\u06d8\u06e2\u06ec\u06e5\u06d8\u06e6\u06e6\u06e5\u06e2\u06dc\u06d7\u06db\u06e1\u06e0\u06e5\u06df\u06d6\u06d7\u06d8\u06dc\u06d8\u06da\u06d6\u06ec\u06d6\u06d8\u06da\u06e7\u06e5\u06e8"

    :goto_3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v5, v4

    sparse-switch v5, :sswitch_data_3

    goto :goto_3

    :sswitch_a
    iget v0, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/16 v5, 0x64

    if-eq v0, v5, :cond_0

    const-string v0, "\u06d9\u06d6\u06e2\u06d8\u06e5\u06e6\u06e4\u06e2\u06e8\u06d8\u06e2\u06d9\u06eb\u06dc\u06dc\u06e4\u06d8\u06dc\u06e0\u06e0\u06d6\u06e5\u06d8\u06e4\u06dc\u06dc\u06d8\u06e8\u06eb\u06e0\u06ec\u06e0\u06e8\u06d6\u06e0\u06d8\u06d9\u06eb\u06e4\u06d9\u06d6\u06d8\u06d8\u06d9\u06e5\u06dc\u06e6\u06da\u06e6\u06d9\u06e4\u06e0\u06df\u06e2\u06e7\u06d8\u06d8"

    goto :goto_3

    :cond_0
    const-string v0, "\u06e7\u06ec\u06e6\u06d8\u06db\u06e6\u06ec\u06eb\u06d8\u06da\u06da\u06e0\u06e5\u06d9\u06dc\u06ec\u06e0\u06e0\u06df\u06ec\u06ec\u06ec\u06e1\u06d6\u06ec\u06ec\u06ec\u06d6\u06db\u06dc\u06db\u06e7\u06e8\u06e7\u06e2\u06e1\u06e8\u06db\u06d8\u06df\u06df\u06e4\u06dc\u06d8\u06df\u06df\u06dc\u06d6\u06d9\u06e1\u06d8\u06e8\u06d7\u06dc\u06d8\u06e6\u06d6\u06dc"

    goto :goto_3

    :sswitch_b
    const-string v0, "\u06ec\u06e0\u06e6\u06d7\u06d6\u06e7\u06d8\u06db\u06dc\u06eb\u06d7\u06e0\u06ec\u06db\u06eb\u06db\u06d9\u06e0\u06e5\u06eb\u06e4\u06e6\u06d8\u06ec\u06e5\u06df\u06e4\u06d7\u06e6\u06e4\u06e2\u06d6\u06e0\u06e6\u06e0\u06e0\u06e7\u06e8\u06d8\u06e2\u06ec\u06e4\u06d6\u06eb\u06e1\u06d8\u06e4\u06e8\u06e4"

    goto :goto_3

    :sswitch_c
    const-string v0, "\u06d9\u06e8\u06d8\u06e4\u06e6\u06e5\u06eb\u06ec\u06e4\u06e1\u06e0\u06e5\u06d8\u06dc\u06e0\u06d6\u06d8\u06df\u06e5\u06d8\u06d9\u06e7\u06db\u06d6\u06eb\u06eb\u06e6\u06e8\u06d8\u06d8\u06e5\u06da\u06e1\u06e1\u06da\u06e8\u06d6\u06e4\u06d7\u06df\u06e1\u06d8\u06ec\u06e8\u06d6\u06df\u06df\u06e7\u06e2\u06d8\u06d8\u06db\u06e6\u06e0\u06d8\u06ec\u06da"

    goto :goto_2

    :sswitch_d
    const-string v0, "\u06e4\u06d6\u06e1\u06d8\u06e0\u06df\u06dc\u06eb\u06e4\u06dc\u06d8\u06db\u06db\u06db\u06dc\u06d7\u06e8\u06e7\u06e6\u06e5\u06e8\u06d7\u06e1\u06e4\u06ec\u06e2\u06d9\u06da\u06e0\u06d8\u06d6\u06ec\u06e1\u06eb\u06e5\u06d8\u06dc\u06e1\u06e8\u06d8\u06ec\u06d7\u06e4\u06d9\u06d7\u06e6\u06e5\u06e2\u06e4\u06dc\u06d6\u06e5\u06e7\u06e6\u06e8\u06e0\u06e1\u06e5\u06dc\u06da\u06d7\u06e7\u06e6\u06da\u06e4"

    goto :goto_2

    :sswitch_e
    const-string v0, "\u06e1\u06e5\u06d7\u06e7\u06df\u06e2\u06e1\u06e5\u06eb\u06ec\u06e5\u06e4\u06e2\u06e5\u06e4\u06e1\u06e7\u06d8\u06d8\u06e6\u06e8\u06dc\u06df\u06e5\u06d8\u06da\u06d8\u06e4\u06db\u06db\u06e0\u06d8\u06d6\u06e8\u06d8\u06e7\u06e4\u06e7\u06e2\u06e8\u06e7\u06dc\u06e7\u06ec\u06d6\u06e0\u06e0"

    goto :goto_1

    :sswitch_f
    const-string v0, "\u06df\u06df\u06d8\u06d8\u06e7\u06e2\u06e1\u06d8\u06e6\u06ec\u06e4\u06ec\u06eb\u06d7\u06d9\u06e0\u06db\u06e6\u06dc\u06e2\u06da\u06e4\u06eb\u06e0\u06dc\u06e4\u06da\u06e0\u06e0\u06d6\u06e8\u06ec\u06d8\u06d7\u06d8\u06d8\u06db\u06d7\u06e2\u06eb\u06e0\u06e1\u06db\u06e2\u06df\u06e1\u06db\u06dc\u06e1\u06dc\u06d9\u06e8\u06e7\u06e1\u06d8\u06df\u06dc\u06e0\u06d6\u06ec\u06e6\u06d8\u06df\u06df\u06ec\u06e8\u06eb\u06d8\u06d8"

    goto :goto_0

    :sswitch_10
    const/4 v0, 0x1

    :goto_4
    return v0

    :sswitch_11
    const/4 v0, 0x0

    goto :goto_4

    nop

    :sswitch_data_0
    .sparse-switch
        -0x7689daa3 -> :sswitch_10
        -0x3977ac98 -> :sswitch_0
        -0xb1d1718 -> :sswitch_3
        0x292d8b29 -> :sswitch_11
        0x5bb0c527 -> :sswitch_1
        0x6354761a -> :sswitch_2
    .end sparse-switch

    :sswitch_data_1
    .sparse-switch
        -0x7fb35f10 -> :sswitch_4
        0x416075e1 -> :sswitch_f
        0x6b463232 -> :sswitch_e
        0x75b8aed9 -> :sswitch_6
    .end sparse-switch

    :sswitch_data_2
    .sparse-switch
        -0x62eb38d2 -> :sswitch_7
        -0x37f89b08 -> :sswitch_9
        -0x14026c47 -> :sswitch_5
        0x6d02ba14 -> :sswitch_d
    .end sparse-switch

    :sswitch_data_3
    .sparse-switch
        -0x2542ae6d -> :sswitch_a
        -0x1cb3b2d6 -> :sswitch_8
        0x40fb1ad0 -> :sswitch_b
        0x57028ab9 -> :sswitch_c
    .end sparse-switch
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 4

    const-string v0, "\u06db\u06ec\u06d7\u06db\u06eb\u06e1\u06d8\u06dc\u06e6\u06da\u06db\u06d9\u06e1\u06df\u06dc\u06e8\u06df\u06df\u06d6\u06e2\u06df\u06ec\u06eb\u06e8\u06d8\u06e0\u06ec\u06e8\u06d8\u06e8\u06ec\u06eb\u06e7\u06d8\u06da\u06e6\u06d6\u06d6\u06d8\u06d7\u06e5\u06ec\u06dc\u06ec\u06df\u06e1\u06e8\u06d8"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x253

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x1d7

    const/16 v2, 0x210

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x361

    const/16 v2, 0x371

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x3aa

    const/16 v2, 0x13c

    const v3, 0x21d7e994

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06e7\u06e5\u06d6\u06d8\u06e8\u06e2\u06dc\u06df\u06e6\u06e0\u06db\u06db\u06eb\u06db\u06d9\u06e7\u06eb\u06dc\u06d7\u06db\u06e6\u06d7\u06e2\u06e8\u06e8\u06db\u06e1\u06e5\u06d8\u06e4\u06e2\u06e5\u06e2\u06dc\u06dc\u06d8\u06e2\u06d9\u06df\u06d9\u06e0\u06e4\u06db\u06e7\u06e4\u06db\u06db\u06e6\u06d8"

    goto :goto_0

    :sswitch_1
    const-string v0, "\u06ec\u06d6\u06d8\u06e6\u06e5\u06d8\u06d8\u06e5\u06d9\u06e6\u06d8\u06d6\u06dc\u06e6\u06d8\u06ec\u06ec\u06e0\u06e2\u06e7\u06e1\u06d9\u06e8\u06d8\u06d8\u06e7\u06d9\u06d6\u06d8\u06d7\u06d8\u06dc\u06d8\u06d8\u06dc\u06e7\u06ec\u06d7\u06e1\u06da\u06da\u06e8\u06d7\u06da\u06d6\u06d8\u06e4\u06e1\u06d7\u06df\u06e4\u06e5\u06d8\u06e2\u06e6\u06e6\u06da\u06e8\u06e5\u06d8\u06e2\u06dc\u06d6\u06e0\u06e6\u06e1\u06e8\u06e5\u06e7\u06d7\u06ec"

    goto :goto_0

    :sswitch_2
    const/4 v0, 0x0

    return-object v0

    :sswitch_data_0
    .sparse-switch
        -0x7264cea1 -> :sswitch_0
        -0x1aa8da42 -> :sswitch_1
        0x7d62fafa -> :sswitch_2
    .end sparse-switch
.end method

.method public onCreate()V
    .locals 6

    const/4 v2, 0x0

    const-string v0, "\u06e5\u06e5\u06e6\u06d8\u06e8\u06da\u06d6\u06e1\u06e6\u06da\u06e5\u06dc\u06dc\u06dc\u06df\u06e6\u06d8\u06d9\u06df\u06d9\u06db\u06e2\u06e7\u06e5\u06dc\u06e8\u06d8\u06e1\u06dc\u06db\u06ec\u06da\u06d8\u06d8\u06d6\u06e7\u06e8\u06d9\u06ec\u06eb\u06d6\u06e6\u06e8\u06e5\u06e4\u06dc\u06d8\u06e8\u06d6\u06eb"

    move-object v1, v2

    move-object v3, v2

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v4, 0x12d

    xor-int/2addr v2, v4

    xor-int/lit16 v2, v2, 0x3aa

    const/16 v4, 0x3c5

    xor-int/2addr v2, v4

    xor-int/lit16 v2, v2, 0x35b

    const/16 v4, 0x20d

    xor-int/2addr v2, v4

    xor-int/lit16 v2, v2, 0x113

    const/16 v4, 0x352

    const v5, -0x2c1ab38

    xor-int/2addr v2, v4

    xor-int/2addr v2, v5

    sparse-switch v2, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06e4\u06d7\u06df\u06e1\u06e8\u06da\u06d8\u06db\u06e0\u06e2\u06e1\u06e6\u06e8\u06e5\u06e0\u06e4\u06d6\u06d8\u06ec\u06dc\u06d7\u06d6\u06da\u06db\u06e5\u06d9\u06e6\u06e8\u06d6\u06e0\u06df\u06d9\u06df\u06e5\u06e8\u06da\u06eb\u06d8\u06eb\u06da\u06e4\u06e5\u06e1\u06df\u06db\u06df\u06d9\u06df\u06e2\u06e4\u06ec\u06d6\u06df\u06d6\u06ec\u06d8\u06db\u06e7\u06e1\u06d9\u06d7\u06e6\u06d8"

    goto :goto_0

    :sswitch_1
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const-string v0, "\u06e4\u06e8\u06df\u06e7\u06df\u06e0\u06eb\u06e6\u06e6\u06e0\u06e8\u06dc\u06d8\u06e7\u06e8\u06eb\u06db\u06da\u06e5\u06d8\u06e8\u06d8\u06e4\u06eb\u06e1\u06db\u06e4\u06df\u06d8\u06dc\u06da\u06d6\u06e0\u06eb\u06dc\u06d8\u06d9\u06db\u06e2\u06d9\u06dc\u06d6\u06d7\u06da\u06e7\u06da\u06d7\u06d6\u06e1\u06d8\u06dc\u06e5\u06e7\u06e8\u06e2\u06d8\u06db\u06d8\u06db\u06e8\u06d7\u06e8\u06e0\u06e2\u06d6\u06e0\u06da\u06e1\u06e5\u06e2\u06e6\u06d8\u06eb\u06d7\u06e0"

    goto :goto_0

    :sswitch_2
    new-instance v2, Lcom/android/support/Menu;

    invoke-direct {v2, p0}, Lcom/android/support/Menu;-><init>(Landroid/content/Context;)V

    const-string v0, "\u06da\u06d6\u06e7\u06df\u06e6\u06db\u06dc\u06e7\u06e6\u06d8\u06e7\u06dc\u06e1\u06d9\u06db\u06e0\u06e1\u06d6\u06e1\u06d8\u06df\u06e7\u06d6\u06eb\u06e5\u06da\u06d6\u06e8\u06e8\u06e0\u06e0\u06eb\u06e0\u06e1\u06e6\u06e1\u06e7\u06e0\u06dc\u06d9\u06d7\u06d8\u06e8\u06dc\u06ec\u06e7\u06e1\u06d8\u06dc\u06e7\u06e5\u06d8\u06dc\u06e1\u06e4\u06e5\u06e6\u06d7\u06e5\u06e7\u06d9\u06df\u06e2\u06db\u06d7\u06dc\u06ec"

    move-object v3, v2

    goto :goto_0

    :sswitch_3
    iput-object v3, p0, Lcom/android/support/Launcher;->menu:Lcom/android/support/Menu;

    const-string v0, "\u06e5\u06e1\u06db\u06e8\u06d6\u06d8\u06da\u06db\u06e4\u06dc\u06d9\u06e1\u06d8\u06d7\u06e5\u06e1\u06d8\u06e0\u06e4\u06e1\u06e1\u06d8\u06dc\u06d8\u06da\u06e5\u06e8\u06e2\u06d6\u06e4\u06eb\u06e7\u06e5\u06d8\u06e7\u06db\u06e6\u06e5\u06e8\u06e5\u06df\u06db\u06e4\u06e6\u06e0\u06e5\u06ec\u06dc\u06d7\u06e7\u06d8\u06d8\u06d7\u06e1\u06e8\u06e0\u06e6\u06ec"

    goto :goto_0

    :sswitch_4
    invoke-virtual {v3}, Lcom/android/support/Menu;->SetWindowManagerWindowService()V

    const-string v0, "\u06d8\u06dc\u06e2\u06e5\u06eb\u06e1\u06da\u06e1\u06db\u06eb\u06ec\u06d8\u06d8\u06ec\u06df\u06e8\u06d8\u06dc\u06d9\u06d6\u06d8\u06da\u06e6\u06e5\u06ec\u06e5\u06d7\u06e0\u06d8\u06d9\u06e8\u06e0\u06d6\u06d8\u06d8\u06dc\u06e1\u06d6\u06d9\u06eb\u06e8\u06e8\u06e6\u06db\u06db\u06e6\u06d8\u06eb\u06da\u06d9\u06db\u06e7\u06d8\u06d7\u06e8\u06e8\u06d8\u06d9\u06e1"

    goto :goto_0

    :sswitch_5
    iget-object v0, p0, Lcom/android/support/Launcher;->menu:Lcom/android/support/Menu;

    invoke-virtual {v0}, Lcom/android/support/Menu;->ShowMenu()V

    const-string v0, "\u06e4\u06e5\u06e8\u06d8\u06e7\u06e5\u06e6\u06db\u06d6\u06e0\u06eb\u06db\u06eb\u06d6\u06e5\u06d8\u06eb\u06eb\u06e0\u06db\u06d7\u06e0\u06e1\u06eb\u06db\u06e7\u06df\u06db\u06e7\u06d8\u06d8\u06db\u06e2\u06e1\u06d8\u06da\u06e8\u06e0\u06d8\u06ec\u06db\u06d8\u06eb\u06e6\u06d8\u06e1\u06e4\u06d9\u06d6\u06e0\u06d6\u06d8\u06db\u06d9\u06dc\u06dc\u06e8\u06e7\u06e6\u06e5\u06e1\u06d8\u06dc\u06df\u06db\u06e4\u06e4\u06dc"

    goto :goto_0

    :sswitch_6
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const-string v0, "\u06d7\u06dc\u06e1\u06e1\u06e2\u06dc\u06e7\u06d6\u06dc\u06d8\u06e8\u06eb\u06d9\u06e1\u06d8\u06e5\u06d8\u06e8\u06e1\u06e5\u06d8\u06e4\u06e1\u06eb\u06e4\u06da\u06dc\u06dc\u06d9\u06e7\u06dc\u06d8\u06db\u06e4\u06e0\u06e0\u06e6\u06eb\u06d9\u06e4\u06dc\u06e8\u06e7\u06eb\u06d6\u06d8\u06d6\u06d7\u06eb"

    goto :goto_0

    :sswitch_7
    new-instance v0, Lcom/android/support/Launcher$1;

    invoke-direct {v0, p0, v1}, Lcom/android/support/Launcher$1;-><init>(Lcom/android/support/Launcher;Landroid/os/Handler;)V

    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const-string v0, "\u06ec\u06da\u06e8\u06e1\u06dc\u06db\u06e7\u06ec\u06d7\u06e1\u06dc\u06d8\u06da\u06e7\u06e0\u06df\u06d6\u06e7\u06e1\u06d7\u06eb\u06e1\u06da\u06dc\u06d8\u06e7\u06e0\u06da\u06d7\u06dc\u06e4\u06ec\u06d8\u06e8\u06d8\u06dc\u06d9\u06d6\u06d8\u06d8\u06e8\u06dc\u06d8\u06e8\u06e2\u06e1\u06da\u06eb\u06e6\u06e2\u06e5\u06d6\u06df\u06e8\u06e5\u06e5"

    goto :goto_0

    :sswitch_8
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x5555f370 -> :sswitch_8
        -0x222ea17f -> :sswitch_5
        -0x14cfae3f -> :sswitch_4
        -0x9260c72 -> :sswitch_7
        0x1e323b26 -> :sswitch_1
        0x42d82570 -> :sswitch_3
        0x535ec916 -> :sswitch_2
        0x66c243b1 -> :sswitch_6
        0x7ca83013 -> :sswitch_0
    .end sparse-switch
.end method

.method public onDestroy()V
    .locals 4

    const-string v0, "\u06e7\u06d9\u06df\u06e6\u06e5\u06e6\u06d8\u06d8\u06e2\u06d8\u06d8\u06d7\u06e1\u06e2\u06d6\u06e1\u06e8\u06db\u06d9\u06e0\u06e8\u06d8\u06e8\u06d8\u06dc\u06d7\u06e5\u06d8\u06db\u06dc\u06db\u06e6\u06e4\u06e8\u06d8\u06da\u06e7\u06e8\u06ec\u06ec\u06df\u06e5\u06e0\u06d9\u06e7\u06df\u06e5\u06e5\u06e4\u06e2\u06d8\u06e4\u06e4\u06e1\u06d6\u06e1\u06e4\u06d9\u06e1\u06db\u06e4\u06d7\u06d9\u06e6\u06d8\u06e4\u06d6\u06d9\u06e7\u06df\u06d8\u06dc\u06d6\u06d8\u06df\u06d7\u06e1\u06d8\u06e5\u06d7\u06db\u06da\u06e8\u06e6\u06d8\u06e5\u06d8\u06d8\u06d8"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x1fb

    xor-int/2addr v1, v2

    xor-int/lit16 v1, v1, 0x19a

    const/16 v2, 0x280

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x18

    const/16 v2, 0x3ae

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x3a

    const/16 v2, 0x13a

    const v3, -0x146c6115

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06df\u06db\u06e2\u06d8\u06e2\u06e8\u06d8\u06e6\u06e5\u06d8\u06d6\u06e6\u06e5\u06d8\u06d7\u06e5\u06ec\u06da\u06e8\u06e4\u06e8\u06e1\u06d8\u06ec\u06d6\u06e8\u06d9\u06e8\u06e6\u06d8\u06e7\u06d7\u06e4\u06d8\u06e1\u06d6\u06dc\u06e7\u06e4\u06e4\u06db\u06da\u06e0\u06d9\u06e6\u06d6\u06d6\u06e7\u06d8\u06e4\u06dc\u06e2\u06da\u06e0\u06d8\u06e0\u06df\u06eb\u06d7\u06db\u06e6\u06db\u06e5\u06d6\u06e6\u06e7\u06db\u06e4\u06e7\u06da\u06e4\u06e0\u06e8\u06e1\u06d9\u06e8\u06e1\u06ec\u06d7\u06eb\u06e8\u06da\u06d7\u06db\u06e0"

    goto :goto_0

    :sswitch_1
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const-string v0, "\u06d7\u06e5\u06d8\u06d8\u06ec\u06e4\u06e8\u06d8\u06e1\u06d7\u06e7\u06e2\u06da\u06e2\u06eb\u06e7\u06ec\u06e0\u06ec\u06db\u06e4\u06d6\u06e0\u06eb\u06db\u06e5\u06d8\u06db\u06dc\u06e5\u06d8\u06ec\u06db\u06d6\u06d8\u06ec\u06e1\u06dc\u06d8\u06da\u06e2\u06eb\u06ec\u06e8\u06e1\u06d8\u06d8\u06e2\u06df\u06d9\u06db\u06e1\u06d8\u06ec\u06d6\u06d6\u06d8\u06e8\u06e5\u06da\u06e6\u06e5\u06e6\u06d8\u06d8\u06e5\u06e6\u06d8\u06ec\u06d7\u06da\u06e4\u06df\u06df\u06e5\u06d8\u06e1\u06d6\u06e0\u06da\u06dc\u06e1\u06da"

    goto :goto_0

    :sswitch_2
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x7fffcd81 -> :sswitch_1
        -0x5ddd61ae -> :sswitch_2
        -0x37a3ef2 -> :sswitch_0
    .end sparse-switch
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 4

    const-string v0, "\u06e2\u06df\u06d9\u06e1\u06e2\u06e7\u06d8\u06d9\u06d9\u06e5\u06e0\u06da\u06e5\u06d6\u06d8\u06db\u06da\u06d9\u06d7\u06db\u06e2\u06e2\u06e2\u06e6\u06d8\u06e4\u06e4\u06e5\u06db\u06e1\u06d7\u06d6\u06d8\u06d6\u06ec\u06dc\u06e6\u06da\u06e4\u06e6\u06ec\u06d7\u06da\u06e2\u06e6\u06d7\u06e0\u06df\u06e0\u06e6\u06d7\u06db\u06dc\u06d8"

    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v2, 0x6a

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x45

    const/16 v2, 0x269

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x3e

    const/16 v2, 0x20a

    xor-int/2addr v1, v2

    xor-int/lit8 v1, v1, 0x6b

    const/16 v2, 0x1ec

    const v3, -0x871509d

    xor-int/2addr v1, v2

    xor-int/2addr v1, v3

    sparse-switch v1, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string v0, "\u06e1\u06df\u06e5\u06d8\u06e6\u06e8\u06e6\u06e8\u06e8\u06d8\u06e4\u06e6\u06d9\u06db\u06d8\u06e8\u06db\u06e0\u06d6\u06e4\u06e8\u06e1\u06da\u06e6\u06dc\u06d6\u06dc\u06d6\u06d7\u06d8\u06d8\u06e5\u06eb\u06eb\u06db\u06dc\u06e1\u06d8\u06df\u06eb\u06ec\u06e5\u06e8\u06e5\u06d8\u06df\u06e1\u06e6\u06d8"

    goto :goto_0

    :sswitch_1
    const-string v0, "\u06dc\u06e1\u06d9\u06db\u06e5\u06e7\u06df\u06e4\u06e5\u06d8\u06eb\u06d9\u06e0\u06dc\u06e6\u06dc\u06e8\u06db\u06e2\u06e5\u06d8\u06d8\u06e6\u06d8\u06db\u06df\u06d9\u06e0\u06e8\u06ec\u06e5\u06df\u06d9\u06d6\u06e0\u06dc\u06d8\u06e8\u06e5\u06e7\u06d8\u06ec\u06da\u06eb\u06da\u06d6\u06da\u06d9\u06ec\u06e5\u06d8\u06e5\u06df\u06df\u06ec\u06d9\u06d6\u06d8\u06df\u06dc\u06d8\u06df\u06e8\u06e8\u06d8\u06d7\u06dc\u06ec"

    goto :goto_0

    :sswitch_2
    const-string v0, "\u06da\u06d7\u06e8\u06eb\u06e7\u06e6\u06e6\u06e4\u06d9\u06da\u06e0\u06e7\u06d9\u06e2\u06d8\u06d8\u06db\u06e1\u06ec\u06df\u06e5\u06db\u06dc\u06d6\u06df\u06da\u06e1\u06d8\u06d7\u06e8\u06e2\u06e4\u06da\u06d9\u06e4\u06e8\u06e6\u06e5\u06ec\u06e8\u06d9\u06d7\u06d9\u06e0\u06dc"

    goto :goto_0

    :sswitch_3
    const-string v0, "\u06da\u06d8\u06e6\u06d8\u06e5\u06eb\u06e5\u06da\u06e7\u06e1\u06d8\u06d8\u06e7\u06d8\u06e8\u06da\u06e5\u06d8\u06e5\u06eb\u06e4\u06d9\u06e8\u06d6\u06e5\u06e6\u06e4\u06db\u06e4\u06d7\u06dc\u06d7\u06d6\u06e4\u06e4\u06df\u06d8\u06d8\u06df\u06e2\u06e6\u06d8\u06e6\u06df\u06da\u06e8\u06e8\u06da\u06e2\u06d8\u06d8\u06ec\u06eb\u06e1\u06d8\u06e6\u06e1\u06d8\u06e8\u06e8\u06e0\u06e6\u06d8\u06e1\u06e6\u06d8\u06e4\u06e2\u06e8\u06e7\u06d8\u06e4\u06eb\u06e5\u06d8\u06e2\u06e5\u06e6"

    goto :goto_0

    :sswitch_4
    const/4 v0, 0x2

    return v0

    :sswitch_data_0
    .sparse-switch
        -0x760aa57d -> :sswitch_4
        -0x42a941ad -> :sswitch_2
        -0x243eed37 -> :sswitch_1
        -0xd251363 -> :sswitch_0
        0x2a2f512b -> :sswitch_3
    .end sparse-switch
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    const-wide/16 v0, 0x64

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    invoke-virtual {p0}, Lcom/android/support/Launcher;->stopSelf()V

    return-void

    :catch_0
    move-exception v0

    goto :goto_0
.end method
